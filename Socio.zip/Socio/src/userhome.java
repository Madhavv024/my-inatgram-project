
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.StringTokenizer;
import java.util.TooManyListenersException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author hp
 */
public class userhome extends javax.swing.JFrame {

    /**
     * Creates new form userhome
     */
    public String user_name;
    Dimension d;
    public userhome(String username) {
        initComponents();
        getContentPane().setBackground(Color.black);
        this.user_name = "" + username;
        heading_lb.setText("Welcome " + user_name);
         d = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(d.width, d.height);
        setVisible(true);
        getallpost();
    }

    public void getallpost() {

        try {
            HttpResponse<String> res = Unirest.get(address.ipaddress + "fetchfollowingpost")
                    .queryString("username", user_name)
                    .asString();
            if (res.getStatus() == 200) {
                String response = res.getBody();
                System.out.println("Response is-------> " + response);
                StringTokenizer st = new StringTokenizer(response, "~~");
                int count = st.countTokens();
                home_pannel_design[] obj = new home_pannel_design[count];
                
//                    repaint();
                int y = 10;
                main_pannel_home.removeAll();
                for (int i = 0; i < count; i++) {
                    final int a = i;
                    String usertoken = st.nextToken();
                    StringTokenizer st2 = new StringTokenizer(usertoken, ";;");
                    String user = st2.nextToken();
                    String photo_path = st2.nextToken();
                    String caption = st2.nextToken();
                    String date_time = st2.nextToken();
                    int post_id = Integer.parseInt(st2.nextToken());
                    String is_like = st2.nextToken();
                    String count_like = st2.nextToken();
//                    System.out.println("photo--------->" + photo_path);
//                    System.out.println("caption------->" + caption);
//                    System.out.println("date time------>" + date_time);
                    obj[i] = new home_pannel_design();
                    obj[i].follower_name_lb.setText("By :- "+user);
                    obj[i].image_lb.setText(photo_path);
                    obj[i].caption_text_area.setText(caption);
//                    obj[i].date_time_lb.setText(date_time);
                    obj[i].likes_lb.setText(count_like);
                    ImageIcon icon = new ImageIcon(photo_path);
                    Image resize = icon.getImage().getScaledInstance(obj[i].image_lb.getWidth(), obj[i].image_lb.getHeight(), Image.SCALE_SMOOTH);
                    obj[i].image_lb.setIcon(new ImageIcon(resize));
                    obj[i].like_btn.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent e) {
//                            super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                            try {

                                HttpResponse<String> httpResponse = Unirest.get(address.ipaddress + "likepost")
                                        .queryString("post_id", post_id)
                                        .queryString("username", user_name)
                                        .asString();

                                if (httpResponse.getStatus() == 200) {
                                    String ans = httpResponse.getBody();
                                    System.out.println(ans);
                                    JOptionPane.showMessageDialog(rootPane, ans);
                                    getallpost();
                                }
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }

                    }
                    );
                    obj[i].addMouseListener(new MouseAdapter() {
                        public void mouseClicked(MouseEvent e) {
//                            super.mouseClicked(e); //To change body of generated methods, choose Tools | Templates.
                            User_Show_Stories obj = new User_Show_Stories(post_id);
                        }

                    }
                    );

                    obj[i].setBounds(10, y, 600, 350);
                    main_pannel_home.add(obj[i]);
                    y += 380;
                    main_pannel_home.repaint();
                    obj[i].repaint();
                }
                main_pannel_home.setPreferredSize(new Dimension(650, count * 380));
                main_pannel_home.repaint();
            }
        } catch (UnirestException ex) {
            Logger.getLogger(user_my_followings.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        heading_lb = new javax.swing.JLabel();
        chnge_pwd_btn = new javax.swing.JButton();
        edit_profile_btn = new javax.swing.JButton();
        search_user_btn = new javax.swing.JButton();
        logout_btn = new javax.swing.JButton();
        followers_btn = new javax.swing.JButton();
        followings_btn = new javax.swing.JButton();
        add_post_btn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        main_pannel_home = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        heading_lb.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        heading_lb.setForeground(new java.awt.Color(255, 255, 255));
        heading_lb.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        heading_lb.setText("Welcome User");
        getContentPane().add(heading_lb);
        heading_lb.setBounds(810, 50, 316, 81);

        chnge_pwd_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        chnge_pwd_btn.setText("Change Password");
        chnge_pwd_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chnge_pwd_btnActionPerformed(evt);
            }
        });
        getContentPane().add(chnge_pwd_btn);
        chnge_pwd_btn.setBounds(810, 190, 316, 56);

        edit_profile_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        edit_profile_btn.setText("Edit Profile");
        edit_profile_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_profile_btnActionPerformed(evt);
            }
        });
        getContentPane().add(edit_profile_btn);
        edit_profile_btn.setBounds(810, 290, 316, 56);

        search_user_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        search_user_btn.setText("Search User");
        search_user_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                search_user_btnActionPerformed(evt);
            }
        });
        getContentPane().add(search_user_btn);
        search_user_btn.setBounds(810, 390, 316, 56);

        logout_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        logout_btn.setText("Logout");
        logout_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout_btnActionPerformed(evt);
            }
        });
        getContentPane().add(logout_btn);
        logout_btn.setBounds(810, 760, 316, 56);

        followers_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        followers_btn.setText("My Followers");
        followers_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                followers_btnActionPerformed(evt);
            }
        });
        getContentPane().add(followers_btn);
        followers_btn.setBounds(810, 480, 316, 56);

        followings_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        followings_btn.setText("My Followings");
        followings_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                followings_btnActionPerformed(evt);
            }
        });
        getContentPane().add(followings_btn);
        followings_btn.setBounds(810, 570, 316, 56);

        add_post_btn.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        add_post_btn.setText("Add Post");
        add_post_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_post_btnActionPerformed(evt);
            }
        });
        getContentPane().add(add_post_btn);
        add_post_btn.setBounds(810, 670, 316, 56);

        main_pannel_home.setBackground(new java.awt.Color(0, 0, 0));
        main_pannel_home.setForeground(new java.awt.Color(255, 255, 255));
        main_pannel_home.setLayout(null);
        jScrollPane1.setViewportView(main_pannel_home);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(1200, 190, 430, 620);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void edit_profile_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_profile_btnActionPerformed
        // TODO add your handling code here:
        new edit_profile(user_name).setVisible(true);
//        dispose();
    }//GEN-LAST:event_edit_profile_btnActionPerformed

    private void chnge_pwd_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chnge_pwd_btnActionPerformed
        // TODO add your handling code here:
        change_pwd obj = new change_pwd(user_name);
        obj.setVisible(true);

    }//GEN-LAST:event_chnge_pwd_btnActionPerformed

    private void logout_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout_btnActionPerformed
        // TODO add your handling code here:
        new userlogin().setVisible(true);
//        dispose();
    }//GEN-LAST:event_logout_btnActionPerformed

    private void search_user_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_search_user_btnActionPerformed
        // TODO add your handling code here:
        new search_user(user_name).setVisible(true);
//        dispose();
    }//GEN-LAST:event_search_user_btnActionPerformed

    private void followers_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_followers_btnActionPerformed
        // TODO add your handling code here:
        new user_my_followers(user_name).setVisible(true);
//        dispose();
    }//GEN-LAST:event_followers_btnActionPerformed

    private void add_post_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_post_btnActionPerformed
        // TODO add your handling code here:
        new user_add_post(user_name).setVisible(true);
//        dispose();
    }//GEN-LAST:event_add_post_btnActionPerformed

    private void followings_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_followings_btnActionPerformed
        // TODO add your handling code here:
        new user_my_followings(user_name).setVisible(true);
//        dispose();
    }//GEN-LAST:event_followings_btnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(userhome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(userhome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(userhome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(userhome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new userhome("").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_post_btn;
    private javax.swing.JButton chnge_pwd_btn;
    private javax.swing.JButton edit_profile_btn;
    private javax.swing.JButton followers_btn;
    private javax.swing.JButton followings_btn;
    private javax.swing.JLabel heading_lb;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout_btn;
    private javax.swing.JPanel main_pannel_home;
    private javax.swing.JButton search_user_btn;
    // End of variables declaration//GEN-END:variables
}
