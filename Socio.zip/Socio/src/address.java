
public class address {
    public static String ipaddress = "http://localhost:8999/";

}
