
import com.vmm.JHTTPServer;
import dbloader.dbloader;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MyWebServerClass extends JHTTPServer {

    public MyWebServerClass(int port) throws IOException {
        super(port);
    }

    @Override
    public Response serve(String uri, String method, Properties header, Properties parms, Properties files) {
        System.out.println("uri is--------------> " + uri);

        Response res = new Response(HTTP_OK, "test/plain", "Hello from server!");

        if (uri.contains("usersignup")) {
            String username = parms.getProperty("username");
            String email = parms.getProperty("email");
            String phone_no = parms.getProperty("phone_no");
            String password = parms.getProperty("password");
            String gender = parms.getProperty("gender");
            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "'");
                if (rs.next()) {
                    res = new Response(HTTP_FORBIDDEN, "text/plain", "User Already Exist");
                } else {
                    String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/user_pics");
                    String photopath = "src/user_pics/" + photoname;
                    rs.moveToInsertRow();
                    rs.updateString("username", username);
                    rs.updateString("email", email);
                    rs.updateString("phonenumber", phone_no);
                    rs.updateString("password", password);
                    rs.updateString("gender", gender);
                    rs.updateString("photo", photopath);
                    rs.insertRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        } else if (uri.contains("userlogin")) {
            String username = parms.getProperty("username");
            String password = parms.getProperty("password");
            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "' and password='" + password + "'");
                if (rs.next()) {
                    res = new Response(HTTP_OK, "text/plain", "Login Successful");
                } else {
                    res = new Response(HTTP_FORBIDDEN, "text/plain", "Login Failed. Please check details or click forgot password");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("userchangepassword")) {
            String username = parms.getProperty("username");
            String oldpass = parms.getProperty("oldpass");
            String newpass = parms.getProperty("newpass");
            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "' and password='" + oldpass + "'");
                if (rs.next()) {
                    rs.updateString("Password", newpass);
                    rs.updateRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                } else {
                    res = new Response(HTTP_OK, "text/plain", "fails");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("getuserdetails")) {
            String ans = "";
            String username = parms.getProperty("username");
            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "'");
                while (rs.next()) {
                    String email = rs.getString("email");
                    String phonenumber = rs.getString("phonenumber");
                    String photo = rs.getString("photo");
                    ans = ans + email + ";;" + phonenumber + ";;" + photo;
                    res = new Response(HTTP_OK, "text/plain", ans);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("updateuserdatawithouphoto")) {
            String username = parms.getProperty("username");
            String email = parms.getProperty("email");
            String phone_no = parms.getProperty("phone_no");

            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "'");
//                if (rs.next()) {
//                    res = new Response(HTTP_FORBIDDEN, "text/plain", "User Already Exist");
                if (rs.next()) {
//                    String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/user_pics");
//                    String photopath = "src/user_pics" + photoname;
//                    rs.moveToInsertRow();
                    rs.updateString("username", username);
                    rs.updateString("email", email);
                    rs.updateString("phonenumber", phone_no);
//                    rs.updateString("password", password);
//                    rs.updateString("gender", gender);
//                    rs.updateString("photo", photopath);
                    rs.updateRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("updateuserdatawithphoto")) {
            String username = parms.getProperty("username");
            String email = parms.getProperty("email");
            String phone_no = parms.getProperty("phone_no");

            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "'");
                if (rs.next()) {
                    String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/user_pics");
                    String photopath = "src/user_pics/" + photoname;
//                    rs.moveToInsertRow();
                    rs.updateString("username", username);
                    rs.updateString("email", email);
                    rs.updateString("phonenumber", phone_no);
//                    rs.updateString("password", password);
//                    rs.updateString("gender", gender);
                    rs.updateString("photo", photopath);
                    rs.updateRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("searchuser")) {
            String username = parms.getProperty("username");
            String keyword = parms.getProperty("keyword");
            try {
                ResultSet rs = dbloader.executeStatement("select * from users where username like '" + keyword + "%' and username!= '" + username + "'");
                String ans = "";
                while (rs.next()) {
                    String user = rs.getString("username");
                    String photo = rs.getString("photo");
                    ans += user + ";;" + photo + "~~";
                }
                if (ans.equals("")) {
                    res = new Response(HTTP_NOTFOUND, "text/plain", "No user found");
                } else {
                    res = new Response(HTTP_OK, "text/plain", ans);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("followuser")) {
            String follow_by = parms.getProperty("followby");
            String follow_to = parms.getProperty("followto");
            try {
                ResultSet rs = dbloader.executeStatement("select * from follow_user where follow_by='" + follow_by + "' and follow_to='" + follow_to + "'");
                if (rs.next()) {
                    rs.deleteRow();
                    res = new Response(HTTP_OK, "text/plain", "unfollowed");
                } else {
                    rs.moveToInsertRow();
                    rs.updateString("follow_by", follow_by);
                    rs.updateString("follow_to", follow_to);
                    rs.insertRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                }
            } catch (Exception ex) {
                Logger.getLogger(MyWebServerClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (uri.contains("getfollowers")) {
            String user = parms.getProperty("username");
            try {
                ResultSet rs = dbloader.executeStatement("select * from follow_user where follow_to='" + user + "'");
                while (rs.next()) {
                    String followername = rs.getString("follow_by");
                    ResultSet rs2 = dbloader.executeStatement("select * from users where username='" + followername + "'");
                    String ans = "";
                    if (rs2.next()) {
                        String email = rs2.getString("email");
                        String photo = rs2.getString("photo");
                        ans += followername + ";;" + email + ";;" + photo + "~~";
                        res = new Response(HTTP_OK, "text/plain", ans);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("getfollowings")) {
            String user = parms.getProperty("username");
            try {
                ResultSet rs = dbloader.executeStatement("select * from follow_user where follow_by='" + user + "'");
                while (rs.next()) {
                    String followingname = rs.getString("follow_to");
                    ResultSet rs2 = dbloader.executeStatement("select * from users where username='" + followingname + "'");
                    String ans = "";
                    if (rs2.next()) {
                        String email = rs2.getString("email");
                        String photo = rs2.getString("photo");
                        ans += followingname + ";;" + email + ";;" + photo + "~~";
                        res = new Response(HTTP_OK, "text/plain", ans);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("useraddpost")) {
            String user = parms.getProperty("username");
            String caption = parms.getProperty("caption");
            try {
                ResultSet rs = dbloader.executeStatement("select * from user_post where username='" + user + "'");
                rs.next();
                String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/user_post_pics");
                String photopath = "src/user_post_pics/" + photoname;
                rs.moveToInsertRow();
                rs.updateString("caption", caption);
                rs.updateString("photo", photopath);
                rs.updateString("username", user);
                rs.insertRow();
                res = new Response(HTTP_OK, "text/plain", "success");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (uri.contains("getallposts")) {
            String user = parms.getProperty("username");
            try {
                ResultSet rs = dbloader.executeStatement("select * from user_post where username='" + user + "'");
                String ans = "";
                while (rs.next()) {
                    String caption = rs.getString("caption");
                    String photo = rs.getString("photo");
                    String date_time = rs.getString("date_time");
                    String post_id = rs.getString("user_postid");
                    ans += photo + ";;" + caption + ";;" + date_time + ";;" + post_id + "~~";
                    res = new Response(HTTP_OK, "text/plain", ans);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("deletepost")) {
            try {
                String post_id = parms.getProperty("post_id");
                ResultSet rs = dbloader.executeStatement("select * from user_post where user_postid='" + post_id + "'");
                if (rs.next()) {
                    rs.deleteRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                } else {
                    res = new Response(HTTP_FORBIDDEN, "text/plain", "failed");
                }
            } catch (Exception ex) {
                Logger.getLogger(MyWebServerClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (uri.contains("useraddstory")) {
            try {
                String post_id = parms.getProperty("post_id");
                String caption = parms.getProperty("caption");
                ResultSet rs = dbloader.executeStatement("select * from user_story where post_id='" + post_id + "'");
                rs.next();
                String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/user_story_pics");
                String photopath = "src/user_story_pics/" + photoname;
                rs.moveToInsertRow();
                rs.updateString("post_id", post_id);
                rs.updateString("caption", caption);
                rs.updateString("photo", photopath);
                rs.insertRow();
                res = new Response(HTTP_OK, "text/plain", "success");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (uri.contains("getallstory")) {
            String post_id = parms.getProperty("post_id");
            try {
                ResultSet rs = dbloader.executeStatement("select * from user_story where post_id='" + post_id + "'");
                String ans = "";
                while (rs.next()) {
                    String caption = rs.getString("caption");
                    String photo = rs.getString("photo");
                    String date_time = rs.getString("date_time");
                    String story_id = rs.getString("user_storyid");
                    ans += photo + ";;" + caption + ";;" + date_time + ";;" + story_id + "~~";
                    res = new Response(HTTP_OK, "text/plain", ans);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (uri.contains("deletestory")) {
            try {
                String story_id = parms.getProperty("story_id");
                ResultSet rs = dbloader.executeStatement("select * from user_post where user_storyid='" + story_id + "'");
                if (rs.next()) {
                    rs.deleteRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                } else {
                    res = new Response(HTTP_FORBIDDEN, "text/plain", "failed");
                }
            } catch (Exception ex) {
                Logger.getLogger(MyWebServerClass.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if (uri.contains("/GetResource")) {
            uri = uri.substring(1);
            uri = uri.substring(uri.indexOf("/") + 1);
            res = sendCompleteFile(uri);
//            System.out.println("Response reference to be send to client-------------" + res);
        } else if (uri.contains("user_forgot_pwd")) {
            String username = parms.getProperty("username");
            try {
                ResultSet rs = dbloader.executeStatement("select * from users where username='" + username + "'");
                if (rs.next()) {
                    int random = (int) (1000 + (9999 - 1000) * Math.random());
                    String otp = random + "";
                    res = new Response(HTTP_OK, "text/plain", otp);
                }
                else
                {
                    res = new Response(HTTP_OK, "text/plain", "fails");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
        } else if(uri.contains("user_change_password"))
        {
            String username = parms.getProperty("username");
            String newpass = parms.getProperty("newpass");
            try {
                ResultSet rs = dbloader.executeStatement("Select * from users where username='" + username + "'");
                if (rs.next()) {
                    rs.updateString("Password", newpass);
                    rs.updateRow();
                    res = new Response(HTTP_OK, "text/plain", "success");
                } else {
                    res = new Response(HTTP_OK, "text/plain", "fails");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } 
        else if (uri.contains("fetchfollowingpost")) {
            String username = parms.getProperty("username");
            String ans = "";
            try {
                ResultSet rs = dbloader.executeStatement("select * from follow_user where follow_by='" + username + "'");
                while (rs.next()) {
                    String follow_to = rs.getString("follow_to");
                    ResultSet rs2 = dbloader.executeStatement("select * from user_post where username='" + follow_to + "'");
                    while (rs2.next()) {
                        int post_id = rs2.getInt("user_postid");
                        String date_time = rs2.getString("date_time");
                        String caption = rs2.getString("caption");
                        String photo = rs2.getString("Photo");
                        String is_like = "";
                        int count_like = 0;
                        ResultSet rs3 = dbloader.executeStatement("select * from like_table where post_id=" + post_id + " and username='" + username + "'");
                        if (rs3.next()) {
                            is_like = "yes";
                        } else {
                            is_like = "no";
                        }
                        ResultSet rs4 = dbloader.executeStatement("select count(*) from like_table where post_id= " + post_id);
                        if (rs4.next()) {
                            count_like = rs4.getInt("count(*)");
                        }
                        ans = ans + follow_to + ";;" + photo + ";;" + caption + ";;" + date_time + ";;" + post_id + ";;" + is_like + ";;" + count_like + "~~";
                    }
                }
                res = new Response(HTTP_OK, "text/plain", ans);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else if (uri.contains("likepost")) {
            int post_id = Integer.parseInt(parms.getProperty("post_id"));
            String username = parms.getProperty("username");
            String ans = "";
            try {
                ResultSet rs = dbloader.executeStatement("select * from like_table where post_id= " + post_id + " and username='" + username + "'");
                if (rs.next()) {
                    rs.deleteRow();
                    ans = "unlike";
                } else {
                    rs.moveToInsertRow();
                    rs.updateString("Username", username);
                    rs.updateInt("Post_id", post_id);
                    rs.insertRow();
                    ans = "like";
                }

                res = new Response(HTTP_OK, "text/plain", ans);

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return res;
    }
}
